package com.example.appendmenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.example.appendmenu.model.MenuList;
import com.example.appendmenu.service.ExpandableListAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button mainBtn, sideBtn, etcBtn, appendBtn, menuBtn;
    private FrameLayout fragmentBoard;
    private EditText insertNewMenuN, insertNewMenuP;
    private Switch optionSel;
    private RecyclerView recyclerView;
    MainFragMent mainFrag;
    FirebaseFirestore firestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mainBtn = (Button) findViewById(R.id.mainBtn);
        sideBtn = (Button) findViewById(R.id.sideBtn);
        etcBtn = (Button) findViewById(R.id.etcBtn);
        appendBtn = (Button) findViewById(R.id.appendBtn);
        menuBtn = (Button) findViewById(R.id.appendBtn);
        fragmentBoard = (FrameLayout) findViewById(R.id.fragmentBoard);
        insertNewMenuN = (EditText) findViewById(R.id.insertNewMenuN);
        insertNewMenuP = (EditText) findViewById(R.id.insertNewMenuP);
        optionSel = (Switch) findViewById(R.id.recHeader);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        selectAll();

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        List<ExpandableListAdapter.Item> data = new ArrayList<>();

        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "옵    션 1 (Size)"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "사 이 즈"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "가    격"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "옵    션 2 (Size)"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "사 이 즈"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "가    격"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "옵    션 3 (Size)"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "사 이 즈"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "가    격"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "옵    션 1 (kind)"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "종    류"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "가    격"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "옵    션 2 (kind)"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "종    류"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "가    격"));

        recyclerView.setAdapter(new ExpandableListAdapter(data));

        appendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, Object> menu = new HashMap<>();

                String menuName = insertNewMenuN.getText().toString();
                String menuPrice = insertNewMenuP.getText().toString();

                menu.put("MenuName", menuName);
                menu.put("MenuPrice", menuPrice);

                firestore.collection("Enterprise_Users").document("a")
                        .collection("MenuList").document(String.format(menuName)).set(menu).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(MainActivity.this, "추가완료", Toast.LENGTH_SHORT).show();
                        selectAll();
                    }
                });
            }
        });

        mainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragmentBoard, mainFrag);
                transaction.commitAllowingStateLoss();
            }
        });

        sideBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                SideFragMent sideFrag = new SideFragMent();
                transaction.replace(R.id.fragmentBoard, sideFrag);
                transaction.commitAllowingStateLoss();
            }
        });

        etcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                EtcFragMent etcFrag = new EtcFragMent();
                transaction.replace(R.id.fragmentBoard, etcFrag);
                transaction.commitAllowingStateLoss();
            }
        });

//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//        화면을 돌리기 위해 다시 실행을 하기 때문에 Activi

        final String[] element = {"-선택-", "메인", "사이드", "음료"};

        Spinner spiner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, element);
        spiner.setAdapter(adapter);

    }

    public void selectAll() {
        List<MenuList> menuLists = new ArrayList<MenuList>();
        firestore.collection("Enterprise_Users").document("a").collection("MenuList")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String menuName = (String) document.getData().get("MenuName");
                                String menuPrice = (String) document.getData().get("MenuPrice");

                                menuLists.add(new MenuList(menuName, menuPrice));
                            }
                            // 켜지자마자 mainmenu_page 조회되도록 셋팅
                            Log.d("menuListOut => ", String.valueOf(menuLists));
                            mainFrag = new MainFragMent(MainActivity.this, menuLists);
                            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                            transaction.replace(R.id.fragmentBoard, mainFrag);
                            transaction.commitAllowingStateLoss();
                        } else {
                            Log.d("DocSnippets", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }
}