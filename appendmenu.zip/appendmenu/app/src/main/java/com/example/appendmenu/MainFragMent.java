package com.example.appendmenu;

import android.content.Context;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;

import androidx.fragment.app.Fragment;

import com.example.appendmenu.model.MenuList;

import java.util.List;

public class MainFragMent extends Fragment {

    static Context context;
    static MenuList menuList;
    static List<MenuList> menuLists;
    MenuItemLayout menuItemLayout;
    GridLayout menuGridL;
    View view;

    public MainFragMent(Context context, List<MenuList> menuLists) {
        this.context = context;
        this.menuLists = menuLists;
    }

    public MainFragMent() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.mainmenu_page, container, false);
        menuGridL = (GridLayout) view.findViewById(R.id.menuGridL);
        menuGridL.setColumnCount(4);
        for (int i = 0; i < menuLists.size(); i++) {
            Log.d("menuListSize => ", String.valueOf(menuLists.size()));
            menuList = new MenuList(menuLists.get(i).getMenuName(), menuLists.get(i).getMenuPrice());
            menuItemLayout = new MenuItemLayout(context, menuList);
            menuGridL.addView(menuItemLayout);
        }
        return view;
    }


}
