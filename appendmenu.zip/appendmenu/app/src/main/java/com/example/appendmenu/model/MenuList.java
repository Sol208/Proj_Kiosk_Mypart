package com.example.appendmenu.model;

public class MenuList {
    private String menuName;
    private String menuPrice;

    public MenuList(String menuName, String menuPrice) {
        this.menuName = menuName;
        this.menuPrice = menuPrice;
    }

    public MenuList() {
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuPrice() {
        return menuPrice;
    }

    public void setMenuPrice(String menuPrice) {
        this.menuPrice = menuPrice;
    }

    @Override
    public String toString() {
        return "MenuList{" +
                "menuName='" + menuName + '\'' +
                ", menuPrice='" + menuPrice + '\'' +
                '}';
    }
}
