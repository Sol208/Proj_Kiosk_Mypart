package com.example.appendmenu.service;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.appendmenu.R;

import java.util.ArrayList;
import java.util.List;

public class ExpandableListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {  // 뷰홀더는 각 아이템을 저장하는 객체이다.
    public static final int HEADER = 0; // HEADER와 CHILD를 구분하기 위한 int값 정의
    public static final int CHILD = 1;  // HEADER와 CHILD를 구분하기 위한 int값 정의

    private List<Item> data;    // 비어있는 아이템 리스트 생성

    public ExpandableListAdapter(List<Item> data) {
        this.data = data;   // MainActivity에서 data를 받아온다.
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) { // ViewHolder의 List를 만들면서 ViewHolderList들의 타입도 지정해준다.
        View view = null;
        Context context = parent.getContext();  // ViewGroup의 Context클래스를 context에 담아 사용 준비를 한다.
        float dp = context.getResources().getDisplayMetrics().density;  // density = mdpi를 기준으로 한 배율. 스케일링 시 곱해지는 값(레이아웃에 배치할 때 데이터가 표시될 위치를 위해)
        int subItemPaddingLeft = (int) (18 * dp);
        int subItemPaddingTopAndBottom = (int) (5 * dp);
        switch (type) { // HEADER와 CHILD가 각각 분류 될 수 있도록 switch를 통해 걸러준다.
            case HEADER:
                LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);   // XML에 미리 정의해둔 툴을 올리는 LayoutInflater 선언
                // parent라는 ViewGroup의 Context(동작)중 SystemService 를 실행하여 inflater변수에 담아준다.
                view = inflater.inflate(R.layout.list_header, parent, false);   // inflater를 이용하여 list_header를 parent에 올려 View 클래스에 담는다.
                ListViewHolder header = new ListViewHolder(view);   // view를 header에 담는다.
                return header;
            case CHILD:
                LayoutInflater inflater_C = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater_C.inflate(R.layout.list_child,parent,false);
                ListViewHolder child = new ListViewHolder(view);

                return child;
        }
        return null;
    }

    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {    // 각 ViewHolder에 이벤트를 주기 위해 번호를 받아온다.
        final Item item = data.get(position);   // data에 대한 List에서 특정순번(position)의 data를 item에 받는다.
        switch (item.type) {    // item List에서 type이 HEADER인 데이터를 확인한다.
            case HEADER:    // HEADER인경우
                final ListViewHolder itemController = (ListViewHolder) holder;  // HeaderList를 담을 ViewHolder를 만든다.
                itemController.refferalItem = item; //itemController의 item을 담는다.
                itemController.header_title.setText(item.text); //itemController의 title(text = Child 인것같음)을 담는다.
                itemController.header_title.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (item.invisibleChildren == null) {   // Child(슬라이드로 조회되는 데이터)가 닫혀있는 경우(펼쳐진 경우 없는것으로 보임 && Click이벤트로 데이터를 지운 경우)
                            item.invisibleChildren = new ArrayList<Item>(); // item에 List를 담을 수 있는 ArrayList를 만들어준다.
                            int count = 0;
                            int pos = data.indexOf(itemController.refferalItem);    // data에서 클릭한 아이템의 순번을 찾아넣는다.(Header의 인덱스를 찾아준다.)
                            while (data.size() > pos + 1 && data.get(pos + 1).type == CHILD) {  // data의 사이즈가 클릭한 Header의 인덱스 + 1보다 크고 Header의 다음 요소 data의 타입이 CHILD일때 돌아가는 반복문
                                item.invisibleChildren.add(data.remove(pos + 1));   // HEADER를 제외한 데이터를 item에 넣어준다.
                                count++;
                            }
                            notifyItemRangeRemoved(pos + 1, count); // (삭제된 첫번째 아이템의 위치, 삭제된 아이템의 개수)
                        } else {
                            int pos = data.indexOf(itemController.refferalItem);    // data에서 클릭한 아이템의 순번을 찾아넣는다.
                            int index = pos + 1;    // CHILD의 인덱스를 정해주기 위해 HEADER + 1의 인덱스를 정의해둔다.
                            for (Item i : item.invisibleChildren) { //  CHILD를 넣어주기 위한 for문
                                data.add(index, i); // 증감식으로 + 된 인덱스에 아이템(CHILD)을 넣어준다.
                                index++;
                            }
                            notifyItemRangeInserted(pos + 1, index - pos - 1);
                            item.invisibleChildren = null;
                        }
                    }
                });
                break;
            case CHILD:
                final ListViewHolder itemController_C = (ListViewHolder) holder;
                itemController_C.refferalItem = item; //itemController의 item을 담는다.
                itemController_C.child_Txt.setText(item.text);
                itemController_C.child_EditTxt.setHint(item.text);

                break;
        }
    }

    @Override
    public int getItemViewType(int position) {
        return data.get(position).type;
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    private class ListViewHolder extends RecyclerView.ViewHolder {
        public Switch header_title;
        public Item refferalItem;
        public TextView child_Txt;
        public EditText child_EditTxt;

        public ListViewHolder(View itemView) {
            super(itemView);
            header_title = (Switch) itemView.findViewById(R.id.recHeader);
            child_Txt = (TextView) itemView.findViewById(R.id.child_txt);
            child_EditTxt = (EditText) itemView.findViewById(R.id.child_EditTxt);
        }
    }

    public static class Item {
        public int type;
        public String text;
        public List<Item> invisibleChildren;

        public Item(){
        }

        public Item(int type, String text){
            this.type = type;
            this.text = text;
        }
    }
}
